// constants.js
export const BASE_API_URL = "https://api.noroff.dev/api/v1";

export const REGISTER_API_URL = `${BASE_API_URL}/social/auth/register`;
export const LOGIN_API_URL = `${BASE_API_URL}/social/auth/login`;
export const POSTS_API_URL = `${BASE_API_URL}/social/posts`;
