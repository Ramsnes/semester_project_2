// bidRenderer.js
// Rendre bids innerHTML her
